from fractions import Fraction

def P(event , space):
    return Fraction(len(event & space), len(space))
S={'MMM','MMF','MFM','MFF','FFM','FFF'}  #space

print(len(S))

B={s for s in S if 'F' in s} #B
print(B)

A={s for s in S if 'FFF' in s} #A
print(A)

A_B = {s for s in B if s.count('F')==3}
P_B = P(B, S)
P_A_B = P(A_B, S)
print(P_A_B/P_B)

