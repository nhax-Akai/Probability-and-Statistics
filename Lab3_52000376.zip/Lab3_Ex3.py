from itertools import product
import random
# Define ranks , suits and cards
Ranks = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K'}
Suits = {'♡', '♢', '♣', '♠'}
Cards = list(product(Ranks , Suits))
print(Cards)
B=random.sample(Cards,3)
print(B)


