from fractions import Fraction


def P(event , space):
    return Fraction(len(event & space), len(space))

S = [('Thanh', 'Nữ'), ('Hồng', 'Nữ'), ('Thương', 'Nữ'), ('Đào', 'Nữ'), ('My', 'Nữ'), ('Yến', 'Nữ'), ('Hạnh', 'Nữ'),('My', 'Nữ'), ('Vy', 'Nữ'), ('Tiên', 'Nữ'), ('Thanh', 'Nam'), ('Thanh', 'Nam'), ('Bình', 'Nam'), ('Nhật', 'Nam'), ('Hào', 'Nam'), ('Đạt', 'Nam'), ('Minh', 'Nam')]
#print(S)

A=[]
for i in S:
    if 'Thanh' in i:
        A.append(i)

B=[]
for i in S:
    if 'Nữ' in i:
        B.append(i)

print(A)
print(B)
A_B=list(set(A) & set(B))
print(A_B)
P_A_B=Fraction (len(A_B),len(S))
print(P_A_B)
P_A=Fraction(len(A),len(S))
print(P_A)
P_B=Fraction(len(B),len(S))
print(P_B)
P_A_with_B= Fraction(P_A_B,P_B)
print(P_A_with_B)

