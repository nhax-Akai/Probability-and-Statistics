import random
import itertools


A={0,1,2,3,4,5}
k=3
num_3_digit=list(itertools.permutations(A,k))
for i in num_3_digit:
    if(i[0]!=0):
        print(i)

num_4_digit=list(itertools.combinations(A,4))
for i in num_4_digit:
    if(i[0]!=0):
        print(i)