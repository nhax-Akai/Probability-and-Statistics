from itertools import product
from operator import index
import random
def simulator_pokerA(n):
    count=0
    Ranks = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K'}
    Suits = {'♡', '♢', '♣', '♠'}
    Cards = list(product(Ranks , Suits))
    for i in range(n):
        index = random.sample(Cards,4)
        #count same suit
        if index[0][1]==index[1][1] and index[1][1]==index[2][1] and index[2][1]==index[3][1]:
            count+=1

    return count/n

print("A:",simulator_pokerA(100000))
print(simulator_pokerA(100))
print(simulator_pokerA(1000))
print(simulator_pokerA(10000))
print(simulator_pokerA(100000))

def simulator_pokerB(n):
    count=0
    Ranks = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K'}
    Suits = {'♡', '♢', '♣', '♠'}
    Cards = list(product(Ranks , Suits))
    for i in range(n):
        index = random.sample(Cards,4)
        #count different suit
        if index[0][1]!=index[1][1] and index[1][1]!=index[2][1] and index[2][1]!=index[3][1] and index[0][1]!=index[2][1]:
            count+=1

    return count/n
print("B:",simulator_pokerB(100000))
print(simulator_pokerB(100))
print(simulator_pokerB(1000))
print(simulator_pokerB(10000))
print(simulator_pokerB(100000))

#same color
def simulator_pokerC(n):
    count=0
    Ranks = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K'}
    Suits = {'♡', '♢', '♣', '♠'}
    Cards = list(product(Ranks , Suits))
    for i in range(n):
        index = random.sample(Cards,4)
        #count same color
        if ((index[0][1]=='♡'or index[0][1]=='♢') and (index[1][1]=='♡'or index[1][1]=='♢') and (index[2][1]=='♡'or index[2][1]=='♢')and (index[3][1]=='♡'or index[3][1]=='♢')) or ((index[0][1]=='♣'or index[0][1]=='♠') and (index[1][1]=='♣'or index[1][1]=='♠') and (index[2][1]=='♣'or index[2][1]=='♠')and (index[3][1]=='♣'or index[3][1]=='♠')):
            count+=1
    return count/n
print("C:",simulator_pokerC(100000))
print(simulator_pokerC(100))
print(simulator_pokerC(1000))
print(simulator_pokerC(10000))

def simulator_pokerD(n):
    count = 0
    Ranks = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K'}
    Suits = {'♡', '♢', '♣', '♠'}
    Cards = list(product(Ranks , Suits))
    for i in range(n):
        index = random.sample(Cards,4)
        if index[0][0] ==index[1][0] and index[1][0] ==index[2][0] and index[2][0] ==index[3][0]:
            count+=1
    return count/n
print("D:",simulator_pokerD(100000))
print(simulator_pokerD(100))
print(simulator_pokerD(1000))
print(simulator_pokerD(10000))


