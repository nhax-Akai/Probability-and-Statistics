import random
def simaltor_dice1(n):
    count = 0;
    for i in range(n):
        die1 = random.randint(1, 6)
        die2 = random.randint(1, 6)
        if die1==die2:
            count+=1
    return count/n

print("Both dice are the same")
print(simaltor_dice1(100))
print(simaltor_dice1(1000))
print(simaltor_dice1(10000))
print(simaltor_dice1(100000))
print(simaltor_dice1(1000000))


def simaltor_dice2(n):
    count = 0;
    for i in range(n):
        die1 = random.randint(1, 6)
        die2 = random.randint(1, 6)
        if die1!=die2:
            count+=1
    return count/n
print("Both dice are different")
print(simaltor_dice2(100))
print(simaltor_dice2(1000))
print(simaltor_dice2(10000))
print(simaltor_dice2(100000))
print(simaltor_dice2(1000000))

def simaltor_dice3(n):
    count = 0;
    for i in range(n):
        die1 = random.randint(1, 6)
        die2 = random.randint(1, 6)
        if die1%2==0 and die2%2==0:
            count+=1
    return count/n
print("Both dice are even")
print(simaltor_dice3(100))
print(simaltor_dice3(1000))
print(simaltor_dice3(10000))
print(simaltor_dice3(100000))

def simaltor_dice4(n):
    count = 0;
    for i in range(n):
        die1 = random.randint(1, 6)
        die2 = random.randint(1, 6)
        if die1%2!=0 and die2%2!=0:
            count+=1
    return count/n

print("Both dice are odd")
print(simaltor_dice4(100))
print(simaltor_dice4(1000))
print(simaltor_dice4(10000))
print(simaltor_dice4(100000))

def simaltor_dice5(n):
    count = 0;
    for i in range(n):
        die1 = random.randint(1, 6)
        die2 = random.randint(1, 6)
        if die1%2==0 and die2%2!=0 or die1%2!=0 and die2%2==0:
            count+=1
    return count/n

print("One dice is even and the other is odd")
print(simaltor_dice5(100))
print(simaltor_dice5(1000))
print(simaltor_dice5(10000))
print(simaltor_dice5(100000))

def simaltor_dice6(n):
    count = 0;
    for i in range(n):
        die1 = random.randint(1, 6)
        die2 = random.randint(1, 6)
        if die1==6 and die2==6:
            count+=1
    return count/n

print("Both dice are 6")
print(simaltor_dice6(100))
print(simaltor_dice6(1000))
print(simaltor_dice6(10000))
print(simaltor_dice6(100000))

def simaltor_dice7(n):
    count = 0;
    for i in range(n):
        die1 = random.randint(1, 6)
        die2 = random.randint(1, 6)
        if die1 + die2 >10:
            count+=1
    return count/n

print("Sum of both dice is greater than 10")
print(simaltor_dice7(100))
print(simaltor_dice7(1000))
print(simaltor_dice7(10000))
print(simaltor_dice7(100000))

