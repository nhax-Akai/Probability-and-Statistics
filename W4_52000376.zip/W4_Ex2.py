import random
import itertools
from itertools import product
from fractions import Fraction

def P(event,space):
    return Fraction(len(event),len(space))


def cross(color,number):
    return {color + num for num in number}

urn = cross('W', '12345') | cross('B', '12') | cross('R', '123')
def combos(items, n):
    return {' '.join(combo) for combo in itertools.combinations(items , n)}
# same color    
U3 = combos(urn, 3)
print("same color:")
samecolor = {s for s in U3 if s.count('W')==3 or s.count('R')==3 }
print(P(samecolor, U3))

def samecolor_balls(n):
    count = 0
    for i in range(n):
        s = random.sample(urn,3)
        if(s[0][0] == s[1][0] == s[2][0]):
            count += 1
    return count/n

print(samecolor_balls(10))
print(samecolor_balls(100))
print(samecolor_balls(1000))
print(samecolor_balls(10000))

print("different color:")
# diffent color
diffcolor= {s for s in U3 if s.count('W')==1 and s.count('B')==1 and s.count('R')==1 }
print(P(diffcolor, U3))

def diffcolor_balls(n):
    count = 0
    for i in range(n):
        s = random.sample(urn,3)
        if(s[0][0] != s[1][0] and s[0][0] != s[2][0] and s[1][0] != s[2][0]):
            count += 1
    return count/n

print(diffcolor_balls(10))
print(diffcolor_balls(100))
print(diffcolor_balls(1000))
print(diffcolor_balls(10000))

#only 2 balls are same color
print("only 2 balls are same color:")
twosamecolor= {s for s in U3 if s.count('W')==2 or s.count('B')==2 or s.count('R')==2 }
print(P(twosamecolor, U3))

def two_samecolor_balls(n):
    count = 0
    for i in range(n):
        s = random.sample(urn,3)
        if(s[0][0] == s[1][0] or s[0][0] == s[2][0] or s[1][0] == s[2][0]):
            count += 1
    return count/n

print(two_samecolor_balls(10))
print(two_samecolor_balls(100))
print(two_samecolor_balls(1000))
print(two_samecolor_balls(100000))

print("redwhite_balls:")
#There are 2 red balls and 1 white ball
redwhite= {s for s in U3 if s.count('W')==1 and s.count('R')==2 }
print(P(redwhite, U3))

def redwhite_balls(n):
    count = 0
    for i in range(n):
        s = random.sample(urn,3)
        if(s[0][0] == 'W' and s[1][0] == 'R' and s[2][0] == 'R' or s[0][0] == 'R' and s[1][0] == 'W' and s[2][0] == 'R' or s[0][0] == 'R' and s[1][0] == 'R' and s[2][0] == 'W'):
            count += 1
    return count/n

print(redwhite_balls(10))
print(redwhite_balls(100))
print(redwhite_balls(1000))
print(redwhite_balls(10000))


#list all the cases that all 3 balls are white
print("white_balls:")
white= {s for s in U3 if s.count('W')==3 }
print(P(white, U3))

def white_balls(n):
    count = 0
    for i in range(n):
        s = random.sample(urn,3)
        if(s[0][0] == 'W' and s[1][0] == 'W' and s[2][0] == 'W'):
            count += 1
    return count/n

print(white_balls(10))
print(white_balls(100))
print(white_balls(1000))
print(white_balls(10000))