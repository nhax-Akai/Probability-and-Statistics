import random
import numpy as np
x=np.random.choice([0,1,2],10000,p=[0.25,0.5,0.25])
#Find the values of random variable X and save to variable X.
X=set(x)
print(X)
#Calculate the probability distribution function of the random variable X and save to variable P.
P=[x.tolist().count(i)/len(x) for i in X]
print(P)
#Calculate the expectation of X.
EX=0
for x in X:
    EX = EX + (x*P[x-1])
print(EX)
#Calculate the variance of X.
VAR=0
for x in X:
    VAR = VAR + ((x-EX)**2)*P[x-1]
print(VAR)
#Calculate the standard deviation of X.
STD=VAR**0.5
print(STD)
#Calculate the probability to have at least one head.
print(1-P[0])

