import random
import numpy as np
x=np.random.choice([0,1,2,3,4,5],3650,p=[0.1,0.2,0.3,0.2,0.15,0.05])
print(x)
#Determine the values of the random variable X and store it in variable x.
X=set(x)
print(X)
#Calculate the probability distribution function of the random variable X and store it in variable P (list type).
P=[x.tolist().count(i)/len(x) for i in X]
print(P)
#Expectations of X
EX=0
for x in X:
    EX = EX + (x*P[x-1])
print(EX)
#Variance of X
VAR=0
for x in X:
    VAR = VAR + ((x-EX)**2)*P[x-1]
print(VAR)
#Standard deviation of X
STD=VAR**0.5
print(STD)

#Calculate the probability of having 3 or more cases.
print(1-P[0]-P[1]-P[2])