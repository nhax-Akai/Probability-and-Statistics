import matplotlib.pyplot as plt
import numpy as np
import math
def pmf_bimon(k,n,p):
    return (math.factorial(n)/(math.factorial(k)*math.factorial(n-k)))*(p**k)*((1-p)**(n-k))

def plot_pmf_bimon(n,p):
    K=list(range(0,n+1))
    P_bimon = [pmf_bimon(k,n,p) for k in K]
    plt.plot(K,P_bimon,'-o')
    axes=plt.gca()
    axes.set_xlim([0,n])
    axes.set_ylim([0,1.1 * max(P_bimon)])
    plt.title('PMF of Bimon(%i,%.2f)'%(n,p))
    plt.xlabel('Number k of successes')
    plt.ylabel('Probability of k successes')
    plt.show()

plot_pmf_bimon(15,0.4)    