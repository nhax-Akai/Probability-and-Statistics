import itertools

def lab1_ex1():
    E=[0,1,2,3,4,5,6,7,8,9]
    k=4
    num_code=list(itertools.permutations(E,k))
    for i in num_code:
        print(i)
    code_lenght=len(num_code)
    print(code_lenght)

def lab1_ex2():
    A=[1,2,3,4,5]
    k=3
    num_3_digit=list(itertools.combinations(A,k))
    for i in num_3_digit:
        print(i)
    num_3_digit_lenght=len(num_3_digit)
    print(num_3_digit_lenght)

def cross(color,number):
    return {color + num for num in number}
def checkColor(s):
    if(s[0][0] == 'W'):
         if( (s[1][0]=='B' and s[2][0]=='R') or (s[1][0]=='R' and s[2][0]=='B')):
             return True
    if(s[0][0] == 'B'):
         if( (s[1][0]=='W' and s[2][0]=='R') or (s[1][0]=='R' and s[2][0]=='W')):
             return True
    if(s[0][0] == 'R'):
         if( (s[1][0]=='B' and s[2][0]=='W') or (s[1][0]=='W' and s[2][0]=='B')):
             return True
    return False    
def lab1_ex3():
    urn=cross('W','123445678') | cross('B','1234456') | cross('R','1234456789')
    n=3
    U3=list(itertools.combinations(urn,n))
    #cau a
    for s in U3:
        print(s)
    #cau b
    i=0
    for s in U3:
        if (checkColor(s) == True):
            print(s)

def lab1_ex5():
    urn=cross('M','123456') | cross('W','123456789')
    n=5
    U5=list(itertools.combinations(urn,n))
    i=0
    for s in U5:
        if(checkGender(s) == True):
            print(s)
            i=i+1
    print(i)        

def checkGender(s):
    if(s[0][0] == 'W' and s[1][0] == 'W'):
        if(s[2][0]=='M' and s[3][0]=='M' and s[4][0]=='M'):
            return True
    if(s[0][0] == 'W' and s[2][0] == 'W'):
        if(s[1][0]=='M' and s[3][0]=='M' and s[4][0]=='M'):
            return True     
    if(s[0][0] == 'W' and s[3][0] == 'W'):
        if(s[1][0]=='M' and s[2][0]=='M' and s[4][0]=='M'):
            return True 
    if(s[0][0] == 'W' and s[4][0] == 'W'):
        if(s[1][0]=='M' and s[2][0]=='M' and s[3][0]=='M'):
            return True
    if(s[1][0] == 'W' and s[2][0] == 'W'):
        if(s[0][0]=='M' and s[3][0]=='M' and s[4][0]=='M'):
            return True
    if(s[1][0] == 'W' and s[3][0] == 'W'):
        if(s[0][0]=='M' and s[2][0]=='M' and s[4][0]=='M'):
            return True
    if(s[1][0] == 'W' and s[4][0] == 'W'):
        if(s[0][0]=='M' and s[2][0]=='M' and s[3][0]=='M'):
            return True
    if(s[2][0] == 'W' and s[3][0] == 'W'):
        if(s[0][0]=='M' and s[1][0]=='M' and s[4][0]=='M'):
            return True
    if(s[2][0] == 'W' and s[4][0] == 'W'):
        if(s[0][0]=='M' and s[1][0]=='M' and s[3][0]=='M'):
            return True
    if(s[3][0] == 'W' and s[4][0] == 'W'):
        if(s[0][0]=='M' and s[1][0]=='M' and s[2][0]=='M'):
            return True      
    return False

def lab1_ex4():
    urn=cross('M','1234') | cross('P','123') | cross('C','12') | cross('L','1')
    print(urn)
lab1_ex1()
lab1_ex2()
lab1_ex3()
lab1_ex5()
lab1_ex4()

