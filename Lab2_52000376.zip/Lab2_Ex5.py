import random

def simaltor_dice5(n):
    count = 0;
    for i in range(n):
        die1 = random.randint(1, 6)
        die2 = random.randint(1, 6)
        if die1+die2 >= 7:
            count+=1
    return count/n
print(simaltor_dice5(100))
print(simaltor_dice5(1000))
print(simaltor_dice5(10000))
print(simaltor_dice5(100000))