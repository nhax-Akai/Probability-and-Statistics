import random
def simaltor_dice4(n):
    count = 0;
    for i in range(n):
        die1 = random.randint(1, 6)
        die2 = random.randint(1, 6)
        if die1==1 and die2==6 or die1==6 and die2==1:
            count+=1
    return count/n

print(simaltor_dice4(100))
print(simaltor_dice4(1000))
print(simaltor_dice4(10000))
print(simaltor_dice4(100000))