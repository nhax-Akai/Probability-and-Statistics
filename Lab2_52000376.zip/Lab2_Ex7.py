from itertools import product
import random
def simulator_poker2(n):
    count=0
    Ranks = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K'}
    Suits = {'♡', '♢', '♣', '♠'}
    Cards = list(product(Ranks , Suits))
    for i in range(n):
        index = random.sample(Cards,4)
        #count different suit
        #if index[0][1]!=index[1][1] and index[1][1]!=index[2][1] and index[2][1]!=index[3][1] and index[0][1]!=index[2][1]:
        if index[0][1]!=index[1][1] and index[0][1]!=index[2][1] and index[0][1]!=index[2][1] and index[0][1]!=index[3][1]:
            if index[1][1]!=index[2][1] and index[1][1]!=index[3][1]:
                if index[2][1]!=index[3][1]:
                    count+=1
                    print(index)
    return count/n

print(simulator_poker2(100))
print(simulator_poker2(1000))
print(simulator_poker2(10000))
print(simulator_poker2(100000))
