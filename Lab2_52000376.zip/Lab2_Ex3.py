import random
def simaltor_dice3(n):
    count = 0;
    for i in range(n):
        die1 = random.randint(1, 6)
        die2 = random.randint(1, 6)
        if die1==die2:
            count+=1
    return count/n
print(simaltor_dice3(100))
print(simaltor_dice3(1000))
print(simaltor_dice3(10000))
print(simaltor_dice3(100000))