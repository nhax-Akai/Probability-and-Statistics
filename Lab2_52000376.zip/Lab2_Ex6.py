from itertools import product
import random
def simualtor_poker1(n):
    count=0
    Ranks = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K'}
    Suits = {'♡', '♢', '♣', '♠'}
    Cards = list(product(Ranks , Suits))
    for i in range(n):
        index = random.sample(Cards,5)
        if index[0][1]=='♡' and index[1][1]=='♡' and index[2][1]=='♡' and index[3][1]=='♡' and index[4][1]=='♡':
            count+=1
    return count/n

print(simualtor_poker1(100))
print(simualtor_poker1(1000))
print(simualtor_poker1(10000))    
print(simualtor_poker1(100000))